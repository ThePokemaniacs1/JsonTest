//
//  DetailViewController.swift
//  JSONTest
//
//  Created by Drake Pamplin on 3/7/18.
//  Copyright © 2018 Drake Pamplin. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var detailDescriptionLabel: UILabel!
    @IBOutlet weak var mediaTitle: UILabel!
    @IBOutlet weak var mediaYear: UILabel!
    @IBOutlet weak var mediaFormat: UILabel!
    @IBOutlet weak var mediaNetwork: UILabel!
    @IBOutlet weak var mediaImage: UIImageView!
    @IBOutlet weak var mediaDescription: UILabel!
    @IBOutlet weak var mediaSummary: UILabel!


    func configureView() {
        // Update the user interface for the detail item.
        if let detail = self.detailItem {
            
            self.navigationItem.title = detail.name
            
            //super.viewDidLoad()
            
           /// self.mediaTitle.text = "test"
            
            if let label = self.mediaTitle {
                label.text = detail.name
                label.lineBreakMode = NSLineBreakMode.byWordWrapping
            }
            else {
                print("welcome to the suck")
            }
            
            if let label = self.mediaYear {
                label.text = detail.yearStart
                if let test = detail.yearEnd {
                    label.text = detail.yearStart + "-" + test
                }
                label.lineBreakMode = NSLineBreakMode.byWordWrapping
            }
            else {
                print("welcome to the suck")
            }
            
            if let label = self.mediaFormat {
                label.text = detail.format
                label.lineBreakMode = NSLineBreakMode.byWordWrapping
            }
            else {
                print("welcome to the suck")
            }
            
            if let label = self.mediaNetwork {
                if let test = detail.network {
                    label.text = test
                }
                else {
                    label.text = detail.studio
                }
                label.lineBreakMode = NSLineBreakMode.byWordWrapping
            }
            else {
                print("welcome to the suck")
            }
            
            if let imageView = mediaImage {
                let url = URL(string: detail.imageURL)
                let data = try? Data(contentsOf: url!) //make sure the image exists
                imageView.image = UIImage(data: data!)
            }
            
            if let label = self.mediaDescription {
                label.text = detail.showDescription
                label.lineBreakMode = NSLineBreakMode.byWordWrapping
            }
            else {
                print("welcome to the suck")
            }
            
            if let label = self.mediaSummary {
                label.text = detail.showSummary
                label.lineBreakMode = NSLineBreakMode.byWordWrapping
            }
            else {
                print("welcome to the suck")
            }
            
            /*
            if let label = self.detailDescriptionLabel {
                label.text = detail.name
            }
            */
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.configureView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    var detailItem: DataObject? {
        didSet {
            // Update the view.
            self.configureView()
        }
    }


}

